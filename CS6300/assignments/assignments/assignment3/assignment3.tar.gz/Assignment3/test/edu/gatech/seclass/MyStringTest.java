package edu.gatech.seclass;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.Timeout.ThreadMode;

import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;

/**
 * Junit test class created for use in Georgia Tech CS6300.
 * <p>
 * This class is provided to interpret your grades via junit tests
 * and as a reminder, should NOT be posted in any public repositories,
 * even after the class has ended.
 */

@Timeout(value = 1, unit = TimeUnit.SECONDS, threadMode = ThreadMode.SEPARATE_THREAD)
public class MyStringTest {

    private MyStringInterface myString;

    @BeforeEach
    public void setUp() {
        myString = new MyString();
    }

    @AfterEach
    public void tearDown() {
        myString = null;
    }

    @Test
    // Description: First count number example in the interface documentation
    public void testCountAlphabeticWords1() {
        myString.setString("My numbers are 11, 96, and thirteen");
        assertEquals(5, myString.countAlphabeticWords());
    }

    @Test
    // Description: <Add test description here>
    public void testCountAlphabeticWords2() {
        fail("Not yet implemented");
    }

    @Test
    // Description: <Add test description here>
    public void testCountAlphabeticWords3() {
        fail("Not yet implemented");
    }

    @Test
    // Description: <Add test description here>
    public void testCountAlphabeticWords4() {
        fail("Not yet implemented");
    }

    @Test
    // Description: <Add test description here>
    public void testSetString1() {
        fail("Not yet implemented");
    }

    @Test
    // Description: Sample encryption 1
    public void testEncrypt1() {
        myString.setString("Cat & 5 DogS");
        assertEquals("tdK & O ylHL", myString.encrypt(5, 3));
    }

    @Test
    // Description: <Add test description here>
    public void testEncrypt2() {
        fail("Not yet implemented");
    }

    @Test
    // Description: <Add test description here>
    public void testEncrypt3() {
        fail("Not yet implemented");
    }

    @Test
    // Description: <Add test description here>
    public void testEncrypt4() {
        fail("Not yet implemented");
    }

    @Test
    // Description: <Add test description here>
    public void testEncrypt5() {
        fail("Not yet implemented");
    }

    @Test
    // Description: <Add test description here>
    public void testEncrypt6() {
        fail("Not yet implemented");
    }

    @Test
    // Description: First convert digits example in the interface documentation
    public void testConvertDigitsToNamesInSubstring1() {
        myString.setString("I'd b3tt3r put s0me d161ts in this 5tr1n6, right?");
        myString.convertDigitsToNamesInSubstring(17, 23);
        assertEquals("I'd b3tt3r put sZerome dOneSix1ts in this 5tr1n6, right?", myString.getString());
    }


    @Test
    // Description: <Add test description here>
    public void testConvertDigitsToNamesInSubstring2() {
        fail("Not yet implemented");
    }

    @Test
    // Description: <Add test description here>
    public void testConvertDigitsToNamesInSubstring3() {
        fail("Not yet implemented");
    }

    @Test
    // Description: <Add test description here>
    public void testConvertDigitsToNamesInSubstring4() {
        fail("Not yet implemented");
    }

    @Test
    // Description: <Add test description here>
    public void testConvertDigitsToNamesInSubstring5() {
        fail("Not yet implemented");
    }
}
